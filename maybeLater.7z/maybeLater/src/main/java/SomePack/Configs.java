package SomePack;

public class Configs {
    protected String dbHost = "localhost";
    protected String dbPort = "5432";
    protected String dbUser = "postgres";
    protected String dbPass = "Assassin1";
    protected String dbName = "testdata";


}
